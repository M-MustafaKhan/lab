#include <iostream>
#include <stack>
#include <vector>
#include <sstream>
#include <map>
#include <cctype>

using namespace std;

// Function to define operator precedence
int precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

// Check if character is operator
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/';
}

// Convert infix to postfix using Shunting Yard algorithm
vector<string> infixToPostfix(const string& expr) {
    stack<char> opStack;
    vector<string> postfix;
    string token;

    for (size_t i = 0; i < expr.size(); ++i) {
        char c = expr[i];

        if (isspace(c)) continue;

        if (isalnum(c)) {
            token = c;
            while (i + 1 < expr.size() && isalnum(expr[i + 1])) {
                token += expr[++i];
            }
            postfix.push_back(token);
        } else if (c == '(') {
            opStack.push(c);
        } else if (c == ')') {
            while (!opStack.empty() && opStack.top() != '(') {
                postfix.push_back(string(1, opStack.top()));
                opStack.pop();
            }
            if (!opStack.empty()) opStack.pop(); // Remove '('
        } else if (isOperator(c)) {
            while (!opStack.empty() && precedence(opStack.top()) >= precedence(c)) {
                postfix.push_back(string(1, opStack.top()));
                opStack.pop();
            }
            opStack.push(c);
        }
    }

    while (!opStack.empty()) {
        postfix.push_back(string(1, opStack.top()));
        opStack.pop();
    }

    return postfix;
}

// Generate stack-based code from postfix expression
void generateStackCode(const vector<string>& postfix) {
    cout << "\nStack Code:\n";
    for (const string& token : postfix) {
        if (isOperator(token[0]) && token.size() == 1) {
            if (token == "+") cout << "ADD\n";
            else if (token == "-") cout << "SUB\n";
            else if (token == "*") cout << "MUL\n";
            else if (token == "/") cout << "DIV\n";
        } else {
            cout << "PUSH " << token << "\n";
        }
    }
}

int main() {
    string expr;
    cout << "Enter an arithmetic expression (e.g., a+b*c): ";
    getline(cin, expr);

    auto postfix = infixToPostfix(expr);

    cout << "\nPostfix Expression: ";
    for (const auto& token : postfix) cout << token << " ";
    cout << endl;

    generateStackCode(postfix);
    return 0;
}

#include <iostream>
#include <map>
#include <set>
#include <queue>
#include <vector>
#include <sstream>

using namespace std;

struct NFA {
    int num_states;
    set<char> alphabet;
    map<int, map<char, set<int>>> transitions;
    int start_state;
    set<int> accept_states;
};

struct DFA {
    set<set<int>> states;
    map<set<int>, map<char, set<int>>> transitions;
    set<int> start_state;
    set<set<int>> accept_states;
};

void inputNFA(NFA &nfa) {
    cout << "Enter number of NFA states: ";
    cin >> nfa.num_states;

    int num_symbols;
    cout << "Enter number of input symbols: ";
    cin >> num_symbols;
    cout << "Enter alphabet symbols (space separated): ";
    for (int i = 0; i < num_symbols; i++) {
        char sym;
        cin >> sym;
        nfa.alphabet.insert(sym);
    }

    cout << "Enter start state: ";
    cin >> nfa.start_state;

    int num_accept;
    cout << "Enter number of accept states: ";
    cin >> num_accept;
    cout << "Enter accept states (space separated): ";
    for (int i = 0; i < num_accept; i++) {
        int state;
        cin >> state;
        nfa.accept_states.insert(state);
    }

    int num_transitions;
    cout << "Enter number of transitions: ";
    cin >> num_transitions;
    cout << "Enter transitions (from_state input_symbol to_state):\n";
    for (int i = 0; i < num_transitions; i++) {
        int from, to;
        char symbol;
        cin >> from >> symbol >> to;
        nfa.transitions[from][symbol].insert(to);
    }
}

void convertNFAtoDFA(NFA &nfa, DFA &dfa) {
    queue<set<int>> unprocessed;
    set<int> start_set = {nfa.start_state};
    dfa.start_state = start_set;
    dfa.states.insert(start_set);
    unprocessed.push(start_set);

    while (!unprocessed.empty()) {
        set<int> current = unprocessed.front();
        unprocessed.pop();

        for (char symbol : nfa.alphabet) {
            set<int> next_set;
            for (int state : current) {
                if (nfa.transitions[state].count(symbol)) {
                    next_set.insert(nfa.transitions[state][symbol].begin(),
                                    nfa.transitions[state][symbol].end());
                }
            }
            if (!next_set.empty()) {
                dfa.transitions[current][symbol] = next_set;
                if (dfa.states.find(next_set) == dfa.states.end()) {
                    dfa.states.insert(next_set);
                    unprocessed.push(next_set);
                }
            }
        }
    }

    // Identify accept states in DFA
    for (const auto &state_set : dfa.states) {
        for (int s : state_set) {
            if (nfa.accept_states.count(s)) {
                dfa.accept_states.insert(state_set);
                break;
            }
        }
    }
}

string setToString(const set<int> &s) {
    stringstream ss;
    ss << "{";
    for (auto it = s.begin(); it != s.end(); ++it) {
        ss << *it;
        if (next(it) != s.end()) ss << ",";
    }
    ss << "}";
    return ss.str();
}

void printDFA(DFA &dfa, const set<char> &alphabet) {
    cout << "\nDFA States:\n";
    for (const auto &state : dfa.states)
        cout << setToString(state) << "\n";

    cout << "\nStart State: " << setToString(dfa.start_state) << "\n";

    cout << "\nAccept States:\n";
    for (const auto &state : dfa.accept_states)
        cout << setToString(state) << "\n";

    cout << "\nDFA Transition Table:\n";
    for (const auto &state : dfa.states) {
        for (char symbol : alphabet) {
            if (dfa.transitions[state].count(symbol)) {
                cout << setToString(state) << " --" << symbol << "--> "
                     << setToString(dfa.transitions[state][symbol]) << "\n";
            }
        }
    }
}

int main() {
    NFA nfa;
    DFA dfa;

    inputNFA(nfa);
    convertNFAtoDFA(nfa, dfa);
    printDFA(dfa, nfa.alphabet);

    return 0;
}

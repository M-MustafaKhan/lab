#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
    int sd, i;
    char buffer[512];
    int read_from_stdin, read_from_sd;
    struct sockaddr_in servaddr, cliaddr;

    if (argc != 3)
    {
        printf("USAGE : client <portno> <server_name>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("CLIENT : socket error\n");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(0L);

    if (bind(sd, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0)
    {
        perror("CLIENT : bind error\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);

    if (connect(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("CLIENT : connect error\n");
        exit(1);
    }

    for (;;)
    {
        read_from_stdin = read(0, buffer, sizeof(buffer));
        if (read_from_stdin < 0)
        {
            perror("CLIENT : read stdin error\n");
            exit(1);
        }

        if (write(sd, buffer, read_from_stdin) != read_from_stdin)
        {
            perror("CLIENT : write sd error\n");
            exit(1);
        }

        read_from_sd = read(sd, buffer, sizeof(buffer));
        if (read_from_sd < 0)
        {
            perror("CLIENT : read sd error\n");
            exit(1);
        }

        if (write(1, buffer, read_from_sd) != read_from_sd)
        {
            perror("CLIENT : write stdout error\n");
            exit(1);
        }
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sock;
    char buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    int no_of_bytes;
    int addrlength, portno;

    if (argc != 4)
    {
        printf("CLIENT : talker <portno> <hostname> <command>\n");
        exit(1);
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("CLIENT : client socket error\n");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(0L);

    if (bind(sock, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0)
    {
        perror("CLIENT : bind failed\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    portno = atoi(argv[1]);
    servaddr.sin_port = htons(portno);
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);

    no_of_bytes = sendto(sock, argv[3], strlen(argv[3]), 0,
                         (struct sockaddr *)&servaddr, sizeof(servaddr));

    if (no_of_bytes < 0)
    {
        perror("CLIENT : sendto error\n");
        exit(1);
    }

    printf("TALKER\n");
    printf("------\n");
    printf("Sent \"%s\" to %s\n", argv[3], inet_ntoa(servaddr.sin_addr));

    return 0;
}

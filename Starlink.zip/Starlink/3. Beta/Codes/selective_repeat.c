#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>

#define WINDOW_SIZE 4

int main() {
    int totalFrames;
    printf("Enter the total number of frames: ");
    scanf("%d", &totalFrames);

    for (int i = 0; i < totalFrames; i += WINDOW_SIZE) {
        printf("Sending frames %d to %d...\n", i + 1, (i + WINDOW_SIZE) < totalFrames ? i + WINDOW_SIZE : totalFrames);

        for (int j = i; j < i + WINDOW_SIZE && j < totalFrames; j++) {
            int isAckReceived = rand() % 2;  
            if (isAckReceived) {
                printf("Acknowledgment received for Frame %d.\n", j + 1);
            } else {
                printf("Timeout!! Frame %d Not Acknowledged\n", j + 1);
                j--;  // Retransmit this frame by decrementing j
            }
        }
    }
    return 0;
}

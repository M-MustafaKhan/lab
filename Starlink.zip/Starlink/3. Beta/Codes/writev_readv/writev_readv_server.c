#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int sockmain, sockcli, i;
    struct sockaddr_in server, client;
    struct iovec iv[3];

    char buffer1[] = "Computer";
    char buffer2[] = "Networks";
    char buffer3[] = "Laboratory";

    iv[0].iov_base = buffer1;
    iv[0].iov_len = sizeof(buffer1) - 1;  
    iv[1].iov_base = buffer2;
    iv[1].iov_len = sizeof(buffer2) - 1;
    iv[2].iov_base = buffer3;
    iv[2].iov_len = sizeof(buffer3) - 1;

    if (argc != 2) {
        printf("Usage: %s <server-port>\n", argv[0]);
        exit(1);
    }

    if ((sockmain = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket error");
        exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(atoi(argv[1]));
    server.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockmain, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("bind error");
        exit(1);
    }

    if (listen(sockmain, 5) < 0) {
        perror("listen error");
        exit(1);
    }

    i = sizeof(client);
    if ((sockcli = accept(sockmain, (struct sockaddr *)&client, &i)) < 0) {
        perror("accept error");
        exit(1);
    }

    if (writev(sockcli, iv, 3) < 0) {
        perror("writev error");
        exit(1);
    }

    printf("Data sent successfully\n");
    close(sockcli);
    close(sockmain);
    return 0;
}

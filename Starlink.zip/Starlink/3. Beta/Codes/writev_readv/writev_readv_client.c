#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int sockmain;
    struct sockaddr_in server, client;
    struct iovec iv[3];

    char buffer1[512];
    char buffer2[512];
    char buffer3[512];

    iv[0].iov_base = buffer1;
    iv[0].iov_len = sizeof(buffer1);
    iv[1].iov_base = buffer2;
    iv[1].iov_len = sizeof(buffer2);
    iv[2].iov_base = buffer3;
    iv[2].iov_len = sizeof(buffer3);

    if (argc != 3) {
        printf("Usage: %s <server-port> <server-ip>\n", argv[0]);
        exit(1);
    }

    if ((sockmain = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket error");
        exit(1);
    }

    client.sin_family = AF_INET;
    client.sin_port = htons(0);
    client.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockmain, (struct sockaddr *)&client, sizeof(client)) < 0) {
        perror("bind error");
        exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(atoi(argv[1]));
    server.sin_addr.s_addr = inet_addr(argv[2]);

    if (connect(sockmain, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("connect error");
        exit(1);
    }

    if (readv(sockmain, iv, 3) < 0) {
        perror("readv error");
        exit(1);
    }

    printf("%s ", buffer1);
    printf("%s ", buffer2);
    printf("%s\n", buffer3);

    close(sockmain);
    return 0;
}

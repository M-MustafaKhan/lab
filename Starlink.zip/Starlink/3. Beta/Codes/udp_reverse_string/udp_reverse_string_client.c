#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sock;
    char buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    int no_of_bytes, servaddrlength, msglength;

    if (argc != 4)
    {
        printf("CLIENT : client <portno> <hostname> <message>\n");
        exit(1);
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("CLIENT : client socket error\n");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(0L);

    if (bind(sock, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0)
    {
        perror("CLIENT : bind failed\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);

    no_of_bytes = sendto(sock, argv[3], strlen(argv[3]), 0,
                         (struct sockaddr *)&servaddr, sizeof(servaddr));
    if (no_of_bytes < 0)
    {
        perror("CLIENT : sendto error\n");
        exit(1);
    }

    servaddrlength = sizeof(servaddr);
    msglength = recvfrom(sock, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&servaddr, &servaddrlength);
    if (msglength < 0)
    {
        perror("CLIENT : recvfrom error\n");
        exit(1);
    }

    printf("CLIENT :\n");
    printf("--------\n");
    printf("Size of string sent to %s is : %d\n", inet_ntoa(servaddr.sin_addr), no_of_bytes);
    buffer[msglength] = '\0';
    printf("Reversed String is : %s\n", buffer);

    return 0;
}

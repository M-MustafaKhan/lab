#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int sockfd;
    int recvbuffsize;
    socklen_t optlen;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    optlen = sizeof(recvbuffsize);
    if (getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &recvbuffsize, &optlen) < 0) {
        perror("getsockopt");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Initial receive buffer size: %d bytes\n", recvbuffsize);

    recvbuffsize += 2048;
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &recvbuffsize, sizeof(recvbuffsize)) < 0) {
        perror("setsockopt");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    optlen = sizeof(recvbuffsize);
    if (getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &recvbuffsize, &optlen) < 0) {
        perror("getsockopt");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("New receive buffer size: %d bytes\n", recvbuffsize);

    close(sockfd);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sd, i, n;
    int buffer[512];
    int servaddrlength, msglength, msgrecv;
    int no_of_bytes;
    struct sockaddr_in servaddr, cliaddr;
    FILE *fp;

    fp = fopen("File.txt", "r");
    i = 0;

    while (!feof(fp))
    {
        fscanf(fp, "%d", &buffer[i++]);
    }

    n = i;
    buffer[511] = n; 
    if (argc != 3)
    {
        printf("USAGE : Client <portno> <hostname>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("CLIENT : socket error\n");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(0L);

    if (bind(sd, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0)
    {
        perror("CLIENT : bind error\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);

    no_of_bytes = sendto(sd, &buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&servaddr, sizeof(servaddr));

    if (no_of_bytes < 0)
    {
        perror("CLIENT : sendto error\n");
        exit(1);
    }

    printf("CLIENT :\n");
    printf("--------\n");
    printf("The sent data : ");
    for (i = 0; i < n; i++)
        printf("%d ", buffer[i]);
    printf("\n");

    servaddrlength = sizeof(servaddr);
    msglength = recvfrom(sd, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&servaddr, &servaddrlength);

    if (msglength < 0)
    {
        perror("CLIENT : recvfrom error\n");
        exit(1);
    }

    printf("No. of elements sent to %s are : %d\n", inet_ntoa(servaddr.sin_addr), n);
    printf("Elements after sorting are : ");
    for (i = 0; i < n; i++)
        printf("%d ", buffer[i]);
    printf("\n");

    return 0;
}

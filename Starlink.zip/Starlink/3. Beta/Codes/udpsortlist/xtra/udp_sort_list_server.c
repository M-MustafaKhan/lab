#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[])
{
    int sd, i, j, t, n;
    int buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    int cliaddrlength, msglength, no_of_bytes;

    if (argc != 2)
    {
        printf("USAGE : server <portno>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("SERVER : socket error\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("SERVER : bind error\n");
        exit(1);
    }

    cliaddrlength = sizeof(cliaddr);
    msglength = recvfrom(sd, (char *)buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&cliaddr, &cliaddrlength);

    if (msglength < 0)
    {
        perror("SERVER : recvfrom error\n");
        exit(1);
    }

    n = buffer[511]; 
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (buffer[i] > buffer[j])
            {
                t = buffer[i];
                buffer[i] = buffer[j];
                buffer[j] = t;
            }
        }
    }

    for (i = 0; i < n; i++)
        printf("%d ", buffer[i]);
    printf("\n");

    no_of_bytes = sendto(sd, (char *)buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&cliaddr, cliaddrlength);

    printf("SERVER :\n");
    printf("---------\n");
    printf("Got data from : %s\n", inet_ntoa(cliaddr.sin_addr));
    printf("Sorting Elements...\n");

    return 0;
}

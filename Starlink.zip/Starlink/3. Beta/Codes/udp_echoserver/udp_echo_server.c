#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sockmain, i;
    char buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    int cliaddrlength, msglength, no_of_bytes;
    int portno;

    if (argc != 2)
    {
        printf("USAGE : Server <portno>\n");
        exit(1);
    }

    if ((sockmain = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("SERVER : socket error\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockmain, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("SERVER : bind error\n");
        exit(1);
    }

    cliaddrlength = sizeof(cliaddr);
    msglength = recvfrom(sockmain, (char *)buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&cliaddr, &cliaddrlength);

    no_of_bytes = sendto(sockmain, buffer, sizeof(buffer), 0,
                         (struct sockaddr *)&cliaddr, cliaddrlength);

    if (msglength < 0)
    {
        perror("SERVER : recvfrom error\n");
        exit(1);
    }

    printf("SERVER :\n");
    printf("--------\n");
    printf("Got data from %s\n", inet_ntoa(cliaddr.sin_addr));

    return 0;
}

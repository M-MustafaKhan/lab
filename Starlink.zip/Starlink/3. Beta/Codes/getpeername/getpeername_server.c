#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: server <portno>\n");
        exit(1);
    }

    int sockmain, client_socket;
    char buffer[512];
    struct sockaddr_in server, client, peer;
    socklen_t client_len, peer_len;

    sockmain = socket(AF_INET, SOCK_STREAM, 0);
    if (sockmain < 0) {
        perror("Socket creation error");
        exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(atoi(argv[1]));
    server.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockmain, (struct sockaddr*)&server, sizeof(server)) < 0) {
        perror("Binding error");
        exit(1);
    }

    if (listen(sockmain, 5) < 0) {
        perror("Listen error");
        exit(1);
    }

    printf("Server is listening on port %d...\n", atoi(argv[1]));

    while (1) {
        client_len = sizeof(client);
        client_socket = accept(sockmain, (struct sockaddr*)&client, &client_len);
        if (client_socket < 0) {
            perror("Accept error");
            exit(1);
        }

        peer_len = sizeof(peer);
        if (getpeername(client_socket, (struct sockaddr*)&peer, &peer_len) < 0) {
            perror("getpeername error");
        } else {
            printf("Connected client IP: %s, Port: %d\n",
                   inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));
        }

        ssize_t n;
        while ((n = read(client_socket, buffer, sizeof(buffer))) > 0) {
            if (write(client_socket, buffer, n) != n) {
                perror("Write error");
                close(client_socket);
                break;
            }
        }
        if (n < 0) {
            perror("Read error");
        }
        close(client_socket);
    }

    close(sockmain);
    return 0;
}

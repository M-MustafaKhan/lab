#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: client <server_port> <server_ip>\n");
        exit(1);
    }

    int sockfd;
    struct sockaddr_in server, peer;
    socklen_t peer_len;
    char buffer[512];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation error");
        exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(atoi(argv[1]));
    server.sin_addr.s_addr = inet_addr(argv[2]);

    if (connect(sockfd, (struct sockaddr*)&server, sizeof(server)) < 0) {
        perror("Connect error");
        exit(1);
    }

    peer_len = sizeof(peer);
    if (getpeername(sockfd, (struct sockaddr*)&peer, &peer_len) < 0) {
        perror("getpeername error");
    } else {
        printf("Connected to server IP: %s, Port: %d\n",
               inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));
    }

    ssize_t n;
    while ((n = read(STDIN_FILENO, buffer, sizeof(buffer))) > 0) {
        if (write(sockfd, buffer, n) != n) {
            perror("Write error");
            exit(1);
        }

        n = read(sockfd, buffer, sizeof(buffer));
        if (n < 0) {
            perror("Read error");
            exit(1);
        }

        if (write(STDOUT_FILENO, buffer, n) != n) {
            perror("Write to stdout error");
            exit(1);
        }
    }

    close(sockfd);
    return 0;
}

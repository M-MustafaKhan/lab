#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
    int sd, nsd;
    char buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    int cliaddrlength, msglength;

    if (argc != 2)
    {
        printf("USAGE : server <portno>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("SERVER : socket error\n");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("SERVER : bind error\n");
        exit(1);
    }

    if (listen(sd, 5) < 0)
    {
        perror("SERVER : listen error\n");
        exit(1);
    }

    for (;;)
    {
        cliaddrlength = sizeof(cliaddr);
        if ((nsd = accept(sd, (struct sockaddr *)&cliaddr, &cliaddrlength)) < 0)
        {
            perror("SERVER : accept error\n");
            exit(1);
        }

        while ((msglength = read(nsd, buffer, sizeof(buffer))) != 0)
        {
            if (msglength < 0)
            {
                perror("SERVER : read error\n");
                exit(1);
            }

            if (write(nsd, buffer, msglength) != msglength)
            {
                perror("SERVER : write error\n");
                exit(1);
            }
        }
    }

    return 0;
}

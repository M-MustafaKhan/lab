#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

int main(int argc, char* argv[]) {
    int sd;
    char buffer[512];
    int read_from_sd;
    struct sockaddr_in servaddr, cliaddr;

    if (argc != 4) {
        printf("USAGE : client <portno> <server_ip> <message>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("CLIENT : socket error");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(0L);

    if (bind(sd, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0) {
        perror("CLIENT : bind error");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);

    if (connect(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("CLIENT : connect error");
        exit(1);
    }

    if (write(sd, argv[3], strlen(argv[3])) != (ssize_t)strlen(argv[3])) {
        perror("CLIENT : write sd error");
        exit(1);
    }

    read_from_sd = read(sd, buffer, sizeof(buffer) - 1);
    if (read_from_sd < 0) {
        perror("CLIENT : read sd error");
        exit(1);
    }
    buffer[read_from_sd] = '\0'; 
    printf("CLIENT : \n---------\n");
    printf("Remote Machine Time : %s\n", buffer);

    close(sd);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int sd, nsd;
    char buffer[512];
    struct sockaddr_in servaddr, cliaddr;
    socklen_t cliaddrlength;
    int msglength;
    time_t curtime;
    char *time_str;

    if (argc != 2) {
        printf("USAGE : server <portno>\n");
        exit(1);
    }

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("SERVER : socket error");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("SERVER : bind error");
        exit(1);
    }

    if (listen(sd, 1) < 0) {
        perror("SERVER : listen error");
        exit(1);
    }

    cliaddrlength = sizeof(cliaddr);
    if ((nsd = accept(sd, (struct sockaddr *)&cliaddr, &cliaddrlength)) < 0) {
        perror("SERVER : accept error");
        exit(1);
    }

    msglength = read(nsd, buffer, sizeof(buffer));
    if (msglength < 0) {
        perror("SERVER : read error");
        exit(1);
    }

    curtime = time(NULL);
    time_str = ctime(&curtime);

    if (write(nsd, time_str, strlen(time_str)) != (ssize_t)strlen(time_str)) {
        perror("SERVER : write error");
        exit(1);
    }

    printf("SERVER : \n---------\n");
    printf("Sent remote machine time to %s\n", inet_ntoa(cliaddr.sin_addr));

    close(nsd);
    close(sd);
    return 0;
}

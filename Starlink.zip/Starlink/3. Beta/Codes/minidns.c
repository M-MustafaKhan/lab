#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 50    
#define MAX_RECORDS 10 
typedef struct {
    char domain[MAX_SIZE];
    char ip_address[MAX_SIZE];
} DNSRecord;

DNSRecord records[MAX_RECORDS];
int numRecords = 0;

void addRecord(const char *domain, const char *ip_address) {
    if (numRecords >= MAX_RECORDS) {
        printf("Maximum number of records reached.\n");
        return;
    }
    strncpy(records[numRecords].domain, domain, MAX_SIZE-1);
    records[numRecords].domain[MAX_SIZE-1] = '\0'; 
    strncpy(records[numRecords].ip_address, ip_address, MAX_SIZE-1);
    records[numRecords].ip_address[MAX_SIZE-1] = '\0'; 
    numRecords++;
}

const char* findIP(const char *domain) {
    for (int i = 0; i < numRecords; i++) {
        if (strcmp(records[i].domain, domain) == 0) {
            return records[i].ip_address;
        }
    }
    return NULL;
}

int main() {
    int choice;
    char domain[MAX_SIZE];
    char ip_address[MAX_SIZE];

    while (1) {
        printf("DNS Menu:\n");
        printf("1. Add a DNS record\n");
        printf("2. Find IP address for a domain\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n');
            printf("Invalid input. Please enter a number.\n\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Enter domain: ");
                scanf("%s", domain);
                printf("Enter IP address: ");
                scanf("%s", ip_address);
                addRecord(domain, ip_address);
                printf("Record added successfully.\n\n");
                break;

            case 2:
                printf("Enter domain: ");
                scanf("%s", domain);
                const char* ip = findIP(domain);
                if (ip != NULL) {
                    printf("IP address: %s\n\n", ip);
                } else {
                    printf("Domain not found.\n\n");
                }
                break;

            case 3:
                printf("Exiting...\n");
                exit(0);

            default:
                printf("Invalid choice. Please try again.\n\n");
        }
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

#define SHM_SIZE 1024

int main()
{
    key_t key = ftok("shared_memory", 65);

    int shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);
    if (shmid == -1)
    {
        perror("shmget");
        exit(1);
    }

    char *shmaddr = (char *)shmat(shmid, (void *)0, 0);
    if (shmaddr == (char *)(-1))
    {
        perror("shmat");
        exit(1);
    }

    pid_t pid = fork();
    if (pid == -1)
    {
        perror("fork");
        exit(1);
    }

    if (pid == 0)
    {
        printf("Waiting for message from the writer...\n");

        while (strcmp(shmaddr, "end") != 0)
        {
            if (strcmp(shmaddr, "") != 0)
            {
                printf("Received message: %s\n", shmaddr);
                strcpy(shmaddr, ""); 
            }
            usleep(100000); 
        }
        printf("Reader process ended.\n");
    }
    else
    {
        printf("Enter a message to send (enter 'end' to finish): ");
        fgets(shmaddr, SHM_SIZE, stdin);

        while (strcmp(shmaddr, "end\n") != 0)
        {
            printf("Enter a message to send (enter 'end' to finish): ");
            fgets(shmaddr, SHM_SIZE, stdin);
        }
        printf("Writer process ended.\n");
    }
    shmdt(shmaddr);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}

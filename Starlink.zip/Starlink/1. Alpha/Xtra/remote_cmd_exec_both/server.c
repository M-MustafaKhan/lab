#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define BUF_SIZE 512
#define PORT 8080

int main(int argc, char *argv[]) {
    int sd;
    char buffer[BUF_SIZE];
    struct sockaddr_in servaddr, cliaddr;
    int cliaddrlength, msglength;
    FILE *fp;

    if (argc != 2) {
        printf("USAGE : server <portno>\n");
        exit(1);
    }

    // Create socket
    if ((sd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("SERVER : socket error");
        exit(1);
    }

    // Setup server address
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    // Bind the socket
    if (bind(sd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("SERVER : bind error");
        exit(1);
    }

    printf("UDP Remote Command Execution Server running on port %s...\n", argv[1]);

    while (1) {
        cliaddrlength = sizeof(cliaddr);
        memset(buffer, 0, BUF_SIZE);

        // Receive command from client
        msglength = recvfrom(sd, (char *)buffer, BUF_SIZE, 0,
                             (struct sockaddr *)&cliaddr, &cliaddrlength);
        if (msglength < 0) {
            perror("SERVER : recvfrom error");
            exit(1);
        }

        buffer[msglength] = '\0';
        printf("\nSERVER :\n--------\nReceived a command from %s:%d\n",
               inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
        printf("Command: %s\n", buffer);

        // If command is "exit", break the loop
        if (strncmp(buffer, "exit", 4) == 0)
            break;

        // Execute the command using popen
        fp = popen(buffer, "r");
        if (fp == NULL) {
            strcpy(buffer, "Command execution failed\n");
            sendto(sd, buffer, strlen(buffer), 0,
                   (struct sockaddr *)&cliaddr, cliaddrlength);
            continue;
        }

        // Read and send output line by line to client and print on server
        while (fgets(buffer, BUF_SIZE, fp) != NULL) {
            printf("OUTPUT: %s", buffer); // Server-side print
            sendto(sd, buffer, strlen(buffer), 0,
                   (struct sockaddr *)&cliaddr, cliaddrlength);
        }

        pclose(fp);

        // Send end marker to signal client to stop reading
        strcpy(buffer, "END_OF_OUTPUT\n");
        sendto(sd, buffer, strlen(buffer), 0,
               (struct sockaddr *)&cliaddr, cliaddrlength);
    }

    close(sd);
    return 0;
}


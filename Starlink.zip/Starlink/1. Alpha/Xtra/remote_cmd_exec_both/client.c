#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    int sock;
    char buffer[BUF_SIZE];
    struct sockaddr_in servaddr, cliaddr;
    socklen_t servlen;
    int portno;

    if (argc != 3) {
        printf("USAGE: client <portno> <server_ip>\n");
        exit(1);
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("CLIENT: socket error");
        exit(1);
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(0);
    cliaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sock, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) < 0) {
        perror("CLIENT: bind error");
        exit(1);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = inet_addr(argv[2]);
    servlen = sizeof(servaddr);

    while (1) {
        printf("\nEnter command to execute (or type 'exit' to quit): ");
        fgets(buffer, BUF_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0'; // Remove newline

        // Send command to server
        sendto(sock, buffer, strlen(buffer), 0,
               (struct sockaddr *)&servaddr, servlen);

        if (strncmp(buffer, "exit", 4) == 0)
            break;

        // Receive and display output
        while (1) {
            int n = recvfrom(sock, buffer, BUF_SIZE - 1, 0,
                             (struct sockaddr *)&servaddr, &servlen);
            if (n < 0) {
                perror("CLIENT: recvfrom error");
                break;
            }

            buffer[n] = '\0';

            if (strstr(buffer, "END_OF_OUTPUT") != NULL)
                break;

            printf("%s", buffer);
        }
    }

    close(sock);
    return 0;
}


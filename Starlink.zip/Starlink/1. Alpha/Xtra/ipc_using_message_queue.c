#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <unistd.h>

#define MAX_MESSAGE_LENGTH 100

struct message {
    long mtype;
    char mtext[MAX_MESSAGE_LENGTH];
};

int main() {
    key_t key = ftok("message_queue", 65);

    int msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1) {
        perror("msgget");
        exit(1);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) {
        struct message received_msg;

        if (msgrcv(msgid, &received_msg, sizeof(received_msg.mtext), 1, 0) == -1) {
            perror("msgrcv");
            exit(1);
        }
        printf("Received message: %s\n", received_msg.mtext);
    } else {
        struct message msg;
        msg.mtype = 1; // Set the message type

        printf("Enter a message to send: ");
        fgets(msg.mtext, sizeof(msg.mtext), stdin);

        msg.mtext[strcspn(msg.mtext, "\n")] = '\0';

        if (msgsnd(msgid, &msg, sizeof(msg.mtext), 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
        printf("Message sent successfully!\n");
    }

    msgctl(msgid, IPC_RMID, NULL);

    return 0;
}

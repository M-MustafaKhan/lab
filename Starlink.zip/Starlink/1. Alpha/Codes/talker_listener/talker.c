#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define PORT 8888

int main() {
  int sock;
  struct sockaddr_in server_addr;
  char message[1024];

  sock = socket(AF_INET, SOCK_DGRAM, 0);

  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(PORT);
  server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

  printf("Enter message to send: ");
  if (!fgets(message, sizeof(message), stdin)) {
    perror("fgets failed");
    exit(1);
  }

  sendto(sock, message, strlen(message), 0, (struct sockaddr *)&server_addr,
         sizeof(server_addr));

  printf("Message sent.\n");

  close(sock);
  return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serv_addr;
    char message[BUFFER_SIZE], response[BUFFER_SIZE];

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    // Connect to server
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server.\n");
    printf("Enter message (or press Enter to trigger timeout): ");
    fgets(message, sizeof(message), stdin);

    if (strlen(message) > 1) {
        send(sockfd, message, strlen(message), 0);
        printf("Message sent to server.\n");
    } else {
        printf("No message sent. Waiting for server response...\n");
    }

    // Listen for response from server
    int n = recv(sockfd, response, sizeof(response) - 1, 0);
    if (n > 0) {
        response[n] = '\0';
        printf("Server says: %s", response);
    } else if (n == 0) {
        printf("Server closed the connection.\n");
    } else {
        perror("recv failed");
    }

    close(sockfd);
    return 0;
}



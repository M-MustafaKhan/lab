#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sock;
    struct sockaddr_in server;
    float basic, hra, da, salary;

    printf("Client: Enter Basic Salary: ");
    scanf("%f", &basic);
    printf("Client: Enter HRA: ");
    scanf("%f", &hra);
    printf("Client: Enter DA: ");
    scanf("%f", &da);

    sock = socket(AF_INET, SOCK_STREAM, 0);
    server.sin_family = AF_INET;
    server.sin_port = htons(9090);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock, (struct sockaddr*)&server, sizeof(server));

    write(sock, &basic, sizeof(float));
    write(sock, &hra, sizeof(float));
    write(sock, &da, sizeof(float));

    read(sock, &salary, sizeof(float));
    printf("Client: Total Salary received from server = %.2f\n", salary);

    close(sock);
    return 0;
}


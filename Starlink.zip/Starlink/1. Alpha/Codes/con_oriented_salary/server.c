#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server, client;
    socklen_t addr_size;
    float basic, hra, da, salary;

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    server.sin_family = AF_INET;
    server.sin_port = htons(9090);
    server.sin_addr.s_addr = INADDR_ANY;

    bind(server_fd, (struct sockaddr*)&server, sizeof(server));
    listen(server_fd, 1);

    printf("Server: Waiting for salary data from client...\n");
    addr_size = sizeof(client);
    client_fd = accept(server_fd, (struct sockaddr*)&client, &addr_size);

    read(client_fd, &basic, sizeof(float));
    read(client_fd, &hra, sizeof(float));
    read(client_fd, &da, sizeof(float));

    salary = basic + hra + da;
    printf("Server: Received - Basic: %.2f, HRA: %.2f, DA: %.2f\n", basic, hra, da);
    printf("Server: Calculated Total Salary = %.2f\n", salary);

    write(client_fd, &salary, sizeof(float));

    close(client_fd);
    close(server_fd);
    return 0;
}

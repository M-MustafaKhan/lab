#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12349
#define BUFFER_SIZE 1024
#define LIST_SIZE 10

typedef struct {
    int search_element;
    int found;
    int position;
    int sorted_list[LIST_SIZE];
} SearchPacket;

// Binary search function
int binary_search(int arr[], int size, int target) {
    int left = 0, right = size - 1;
    
    while (left <= right) {
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid;  // Element found
        }
        
        if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    
    return -1;  // Element not found
}

// Comparison function for qsort
int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

void handle_client(int client_sock) {
    SearchPacket packet;
    int bytes_received;
    int i;

    printf("Handling client search request...\n");

    // Receive search request
    bytes_received = recv(client_sock, (char*)&packet, sizeof(packet), 0);
    if (bytes_received <= 0) {
        printf("Failed to receive search request\n");
        close(client_sock);
        return;
    }

    printf("Search request for element: %d\n", packet.search_element);
    printf("Client's original list: ");
    for (i = 0; i < LIST_SIZE; i++) {
        printf("%d ", packet.sorted_list[i]);
    }
    printf("\n");

    // Sort the client's list
    qsort(packet.sorted_list, LIST_SIZE, sizeof(int), compare);

    printf("Sorted list: ");
    for (i = 0; i < LIST_SIZE; i++) {
        printf("%d ", packet.sorted_list[i]);
    }
    printf("\n");

    // Perform binary search on the sorted list
    packet.position = binary_search(packet.sorted_list, LIST_SIZE, packet.search_element);
    packet.found = (packet.position != -1);

    if (packet.found) {
        printf("Element %d found at position %d\n", packet.search_element, packet.position);
    } else {
        printf("Element %d not found\n", packet.search_element);
    }

    // Send response back to client
    send(client_sock, (char*)&packet, sizeof(packet), 0);

    printf("Sent response back to client\n\n");
    close(client_sock);
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len;

    // Create TCP socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        printf("Bind failed\n");
        close(server_sock);
        return 1;
    }

    // Listen for connections
    if (listen(server_sock, 5) == -1) {
        printf("Listen failed\n");
        close(server_sock);
        return 1;
    }

    printf("TCP Search Server Started\n");
    printf("Listening on port %d...\n", SERVER_PORT);
    printf("Waiting for clients to send lists and search requests...\n\n");

    while (1) {
        client_addr_len = sizeof(client_addr);
        
        // Accept client connection
        client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_sock == -1) {
            printf("Accept failed\n");
            continue;
        }

        printf("Client connected from %s:%d\n", 
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Handle client request
        handle_client(client_sock);
    }

    close(server_sock);
    return 0;
}

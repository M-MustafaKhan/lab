#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>

int main() {
    int sockfd;
    int size = 1024;
    socklen_t optlen = sizeof(size);

    // Create a TCP socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Set the send buffer size
    if (setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &size, sizeof(size)) < 0) {
        perror("setsockopt failed");
        close(sockfd);
        return 1;
    }

    // Verify the buffer size
    if (getsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &size, &optlen) < 0) {
        perror("getsockopt failed");
        close(sockfd);
        return 1;
    }

    printf("Send buffer size set to: %d bytes\n", size);

    close(sockfd);
    return 0;
}

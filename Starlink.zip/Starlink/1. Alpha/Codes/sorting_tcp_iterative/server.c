#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12346
#define BUFFER_SIZE 1024
#define MAX_NUMBERS 100

// Comparison function for qsort
int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

void handle_client(int client_sock) {
    int numbers[MAX_NUMBERS];
    int count, i;
    int bytes_received;

    printf("Handling client connection...\n");

    // Receive count
    bytes_received = recv(client_sock, (char*)&count, sizeof(count), 0);
    if (bytes_received <= 0) {
        printf("Failed to receive count\n");
        close(client_sock);
        return;
    }

    printf("Received count: %d\n", count);

    // Receive numbers
    bytes_received = recv(client_sock, (char*)numbers, count * sizeof(int), 0);
    if (bytes_received <= 0) {
        printf("Failed to receive numbers\n");
        close(client_sock);
        return;
    }

    printf("Received numbers: ");
    for (i = 0; i < count; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    // Sort the numbers
    qsort(numbers, count, sizeof(int), compare);

    printf("Sorted numbers: ");
    for (i = 0; i < count; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    // Send sorted numbers back
    send(client_sock, (char*)numbers, count * sizeof(int), 0);

    printf("Sent sorted numbers back to client\n\n");
    close(client_sock);
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len;

    // Create TCP socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        printf("Bind failed\n");
        close(server_sock);
        return 1;
    }

    // Listen for connections
    if (listen(server_sock, 5) == -1) {
        printf("Listen failed\n");
        close(server_sock);
        return 1;
    }

    printf("TCP Iterative Sorting Server Started\n");
    printf("Listening on port %d...\n\n", SERVER_PORT);

    while (1) {
        client_addr_len = sizeof(client_addr);
        
        // Accept client connection
        client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_addr_len);
        if (client_sock == -1) {
            printf("Accept failed\n");
            continue;
        }

        printf("Client connected from %s:%d\n", 
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Handle client (iterative - one at a time)
        handle_client(client_sock);
    }

    close(server_sock);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/uio.h>

int main() {
    int fd;
    struct iovec iov[2];
    char buf1[10], buf2[20];

    // Open a file for reading and writing
    fd = open("sample.txt", O_RDWR | O_CREAT, 0644);
    if (fd < 0) {
        perror("open");
        exit(1);
    }

    // ---- Gather Write (writev): write two buffers in one syscall ----
    strcpy(buf1, "Hello ");
    strcpy(buf2, "World!\n");

    iov[0].iov_base = buf1;
    iov[0].iov_len  = strlen(buf1);
    iov[1].iov_base = buf2;
    iov[1].iov_len  = strlen(buf2);

    if (writev(fd, iov, 2) < 0) {
        perror("writev");
        close(fd);
        exit(1);
    }

    // Move file offset to start
    lseek(fd, 0, SEEK_SET);

    // Clear buffers
    memset(buf1, 0, sizeof(buf1));
    memset(buf2, 0, sizeof(buf2));

    // ---- Scatter Read (readv): read into two buffers from file ----
    iov[0].iov_base = buf1;
    iov[0].iov_len  = sizeof(buf1) - 1;
    iov[1].iov_base = buf2;
    iov[1].iov_len  = sizeof(buf2) - 1;

    if (readv(fd, iov, 2) < 0) {
        perror("readv");
        close(fd);
        exit(1);
    }

    // Print what was read
    printf("Buffer 1: %s\n", buf1);
    printf("Buffer 2: %s\n", buf2);

    close(fd);
    return 0;
}


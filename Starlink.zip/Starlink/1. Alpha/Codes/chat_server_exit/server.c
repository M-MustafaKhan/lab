#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int main() {
    int server_fd, client_fd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t addr_len = sizeof(cli_addr);
    char buffer[MAX];

    // Socket creation
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Server address setup
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

    // Bind
    bind(server_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

    // Listen
    listen(server_fd, 1);
    printf("Waiting for client...\n");

    // Accept
    client_fd = accept(server_fd, (struct sockaddr *)&cli_addr, &addr_len);
    printf("Client connected.\n");

    while (1) {
        // Receive from client
        memset(buffer, 0, MAX);
        recv(client_fd, buffer, MAX, 0);
        printf("Client: %s", buffer);
        if (strncmp(buffer, "Exit", 4) == 0)
            break;

        // Send to client
        memset(buffer, 0, MAX);
        printf("You: ");
        fgets(buffer, MAX, stdin);
        send(client_fd, buffer, strlen(buffer), 0);
        if (strncmp(buffer, "Exit", 4) == 0)
            break;
    }

    printf("Chat ended.\n");
    close(client_fd);
    close(server_fd);
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX 1024

int main() {
    int sock;
    struct sockaddr_in serv_addr;
    char buffer[MAX];

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Server setup
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    // Connect
    connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    printf("Connected to server.\n");

    while (1) {
        // Send to server
        memset(buffer, 0, MAX);
        printf("You: ");
        fgets(buffer, MAX, stdin);
        send(sock, buffer, strlen(buffer), 0);
        if (strncmp(buffer, "Exit", 4) == 0)
            break;

        // Receive from server
        memset(buffer, 0, MAX);
        recv(sock, buffer, MAX, 0);
        printf("Server: %s", buffer);
        if (strncmp(buffer, "Exit", 4) == 0)
            break;
    }

    printf("Chat ended.\n");
    close(sock);
    return 0;
}


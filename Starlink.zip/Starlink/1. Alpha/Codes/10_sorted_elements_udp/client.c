#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12350
#define BUFFER_SIZE 1024
#define LIST_SIZE 10

typedef struct {
    int search_element;
    int found;
    int position;
    int sorted_list[LIST_SIZE];
} SearchPacket;

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    SearchPacket packet;
    int i;

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("UDP Search Client\n");

    // Get unsorted list from user
    printf("Enter %d elements for the list (will be sorted automatically):\n", LIST_SIZE);
    for (i = 0; i < LIST_SIZE; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &packet.sorted_list[i]);
    }

    // Get element to search from user
    printf("Enter element to search in the list: ");
    scanf("%d", &packet.search_element);

    // Send search request to server
    sendto(sockfd, (char*)&packet, sizeof(packet), 0,
           (struct sockaddr*)&server_addr, sizeof(server_addr));

    printf("Sent search request for element %d with your list...\n", packet.search_element);

    // Receive response from server
    socklen_t addr_len = sizeof(server_addr);
    recvfrom(sockfd, (char*)&packet, sizeof(packet), 0,
             (struct sockaddr*)&server_addr, &addr_len);

    printf("\nReceived response from server:\n");
    printf("Your sorted list: ");
    for (i = 0; i < LIST_SIZE; i++) {
        printf("%d ", packet.sorted_list[i]);
    }
    printf("\n");

    if (packet.found) {
        printf("Element %d found at position %d (0-indexed)\n", 
               packet.search_element, packet.position);
    } else {
        printf("Element %d not found in the list\n", packet.search_element);
    }

    close(sockfd);
    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define PORT 12345
#define BUFFER_SIZE 1024

void handle_client(int client_sockfd) {
    char buffer[BUFFER_SIZE];
    int n;

    while ((n = read(client_sockfd, buffer, BUFFER_SIZE)) > 0) {
        buffer[n] = '\0';
        printf("Received: %s", buffer);
        write(client_sockfd, buffer, n); // Echo back
    }

    close(client_sockfd);
    printf("Client disconnected.\n");
    exit(0); // End child process
}

int main() {
    int server_sockfd, client_sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    // Ignore SIGCHLD to prevent zombie processes
    signal(SIGCHLD, SIG_IGN);

    // Create TCP socket
    if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Prepare server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY; // Bind to all interfaces
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    // Listen
    if (listen(server_sockfd, 5) < 0) {
        perror("Listen failed");
        close(server_sockfd);
        exit(EXIT_FAILURE);
    }

    printf("TCP Concurrent Echo Server running on port %d...\n", PORT);

    while (1) {
        // Accept a new client
        if ((client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_addr, &client_len)) < 0) {
            perror("Accept failed");
            continue;
        }

        printf("Client connected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Create a child process to handle the client
        if (fork() == 0) {
            close(server_sockfd);  // Child doesn't need the listener
            handle_client(client_sockfd);
        }

        close(client_sockfd); // Parent doesn't need this socket
    }

    close(server_sockfd);
    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12348
#define BUFFER_SIZE 1024
#define MAX_NUMBERS 100

typedef struct {
    int count;
    int numbers[MAX_NUMBERS];
} NumberPacket;

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    NumberPacket packet;
    int i;

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("UDP Sorting Client\n");

    // Get number count from user
    printf("Enter the number of elements to sort (max %d): ", MAX_NUMBERS);
    scanf("%d", &packet.count);

    if (packet.count <= 0 || packet.count > MAX_NUMBERS) {
        printf("Invalid number count\n");
        close(sockfd);
        return 1;
    }

    // Get numbers from user
    printf("Enter %d unsorted numbers:\n", packet.count);
    for (i = 0; i < packet.count; i++) {
        printf("Number %d: ", i + 1);
        scanf("%d", &packet.numbers[i]);
    }

    printf("\nUnsorted numbers: ");
    for (i = 0; i < packet.count; i++) {
        printf("%d ", packet.numbers[i]);
    }
    printf("\n");

    // Send packet to server
    sendto(sockfd, (char*)&packet, sizeof(packet), 0,
           (struct sockaddr*)&server_addr, sizeof(server_addr));

    printf("Sent numbers to server for sorting...\n");

    // Receive sorted packet
    socklen_t addr_len = sizeof(server_addr);
    recvfrom(sockfd, (char*)&packet, sizeof(packet), 0,
             (struct sockaddr*)&server_addr, &addr_len);

    printf("\nReceived sorted numbers from server:\n");
    for (i = 0; i < packet.count; i++) {
        printf("%d ", packet.numbers[i]);
    }
    printf("\n");

    close(sockfd);
    return 0;
}

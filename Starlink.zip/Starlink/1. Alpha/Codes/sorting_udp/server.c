#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12348
#define BUFFER_SIZE 1024
#define MAX_NUMBERS 100

typedef struct {
    int count;
    int numbers[MAX_NUMBERS];
} NumberPacket;

// Comparison function for qsort
int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    NumberPacket packet;
    int bytes_received;
    socklen_t client_addr_len;
    int i;

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        printf("Bind failed\n");
        close(sockfd);
        return 1;
    }

    printf("UDP Sorting Server Started\n");
    printf("Listening on port %d...\n\n", SERVER_PORT);

    while (1) {
        client_addr_len = sizeof(client_addr);
        
        // Receive packet from client
        bytes_received = recvfrom(sockfd, (char*)&packet, sizeof(packet), 0,
                                 (struct sockaddr*)&client_addr, &client_addr_len);
        
        if (bytes_received == -1) {
            printf("Receive failed\n");
            continue;
        }

        printf("Received request from %s:%d\n", 
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        printf("Count: %d\n", packet.count);
        printf("Unsorted numbers: ");
        for (i = 0; i < packet.count; i++) {
            printf("%d ", packet.numbers[i]);
        }
        printf("\n");

        // Sort the numbers
        qsort(packet.numbers, packet.count, sizeof(int), compare);

        printf("Sorted numbers: ");
        for (i = 0; i < packet.count; i++) {
            printf("%d ", packet.numbers[i]);
        }
        printf("\n");

        // Send sorted packet back to client
        sendto(sockfd, (char*)&packet, sizeof(packet), 0,
               (struct sockaddr*)&client_addr, client_addr_len);

        printf("Sent sorted numbers back to client\n\n");
    }

    close(sockfd);
    return 0;
}


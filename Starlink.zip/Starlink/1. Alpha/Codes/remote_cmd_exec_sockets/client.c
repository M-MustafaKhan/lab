#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8888
#define BUF_SIZE 1024

int main() {
    int sock;
    char buffer[BUF_SIZE];
    struct sockaddr_in server_addr;

    sock = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Change to server IP if remote

    connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr));

    while (1) {
        printf("Enter command: ");
        fgets(buffer, BUF_SIZE, stdin);
        send(sock, buffer, strlen(buffer), 0);

        if (strncmp(buffer, "exit", 4) == 0)
            break;

        memset(buffer, 0, BUF_SIZE);
        int bytes = recv(sock, buffer, BUF_SIZE - 1, 0);
        while (bytes > 0) {
            buffer[bytes] = '\0';
            printf("%s", buffer);
            bytes = recv(sock, buffer, BUF_SIZE - 1, MSG_DONTWAIT);
            if (bytes <= 0) break;
        }
        printf("\n");
    }

    close(sock);
    return 0;
}


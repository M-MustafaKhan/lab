#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sockfd;
    char msg[100];
    struct sockaddr_in serv;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    serv.sin_family = AF_INET;
    serv.sin_port = htons(12345);
    serv.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sockfd, (struct sockaddr *)&serv, sizeof(serv));

    printf("Enter message: ");
    fgets(msg, sizeof(msg), stdin);
    msg[strcspn(msg, "\n")] = '\0';  // remove newline

    write(sockfd, msg, strlen(msg));

    int n = read(sockfd, msg, sizeof(msg));
    msg[n] = '\0';

    printf("Reversed from server: %s\n", msg);

    close(sockfd);
    return 0;
}


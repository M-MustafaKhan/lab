#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

void reverse(char *str) {
    int i, len = strlen(str);
    for (i = 0; i < len / 2; i++) {
        char temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
}

int main() {
    int sockfd, clientfd;
    char msg[100];
    struct sockaddr_in serv, cli;
    socklen_t cli_len = sizeof(cli);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    serv.sin_family = AF_INET;
    serv.sin_port = htons(12345);
    serv.sin_addr.s_addr = INADDR_ANY;

    bind(sockfd, (struct sockaddr *)&serv, sizeof(serv));
    listen(sockfd, 5);

    printf("Server is running...\n");

    while (1) {
        clientfd = accept(sockfd, (struct sockaddr *)&cli, &cli_len);
        printf("Client connected.\n");

        int n = read(clientfd, msg, sizeof(msg));
        msg[n] = '\0';

        reverse(msg); // Reverse the string
        write(clientfd, msg, strlen(msg));

        close(clientfd);
        printf("Client disconnected.\n");
    }

    close(sockfd);
    return 0;
}


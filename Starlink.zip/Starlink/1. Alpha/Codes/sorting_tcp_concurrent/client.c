#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>

#define SERVER_PORT 12347
#define BUFFER_SIZE 1024
#define MAX_NUMBERS 100

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    int numbers[MAX_NUMBERS];
    int count, i;

    // Create TCP socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("Socket creation failed\n");
        return 1;
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to server
    if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        printf("Connection failed\n");
        close(sockfd);
        return 1;
    }

    printf("Connected to TCP Concurrent Sorting Server (Port %d)\n", SERVER_PORT);

    // Get number count from user
    printf("Enter the number of elements to sort (max %d): ", MAX_NUMBERS);
    scanf("%d", &count);

    if (count <= 0 || count > MAX_NUMBERS) {
        printf("Invalid number count\n");
        close(sockfd);
        return 1;
    }

    // Get numbers from user
    printf("Enter %d unsorted numbers:\n", count);
    for (i = 0; i < count; i++) {
        printf("Number %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    // Send count first
    send(sockfd, (char*)&count, sizeof(count), 0);

    // Send numbers to server
    send(sockfd, (char*)numbers, count * sizeof(int), 0);

    printf("\nSent %d numbers to concurrent server for sorting...\n", count);

    // Receive sorted numbers
    recv(sockfd, (char*)numbers, count * sizeof(int), 0);

    printf("\nReceived sorted numbers from concurrent server:\n");
    for (i = 0; i < count; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    close(sockfd);
    return 0;
}


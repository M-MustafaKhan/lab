#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <string.h>

int main() {
    fd_set read_fds;
    struct timeval timeout;
    char buffer[1024];

    // Clear the set and add STDIN (fd 0)
    FD_ZERO(&read_fds);
    FD_SET(0, &read_fds); // 0 is the file descriptor for stdin

    // Set timeout to 5 seconds
    timeout.tv_sec = 5;
    timeout.tv_usec = 0;

    printf("Waiting for input (5 seconds)...\n");

    // select() blocks until input is available or timeout occurs
    int ret = select(1, &read_fds, NULL, NULL, &timeout);

    if (ret == -1) {
        perror("select error");
        exit(EXIT_FAILURE);
    } else if (ret == 0) {
        printf("Time out\n");
    } else {
        if (FD_ISSET(0, &read_fds)) {
            fgets(buffer, sizeof(buffer), stdin);
            printf("Input received: %s", buffer);
        }
    }

    return 0;
}


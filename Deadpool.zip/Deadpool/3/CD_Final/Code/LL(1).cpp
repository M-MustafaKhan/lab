#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <stack>
#include <algorithm>
using namespace std;

map<char, vector<string>> grammar;
map<char, set<char>> FIRST, FOLLOW;
map<pair<char, char>, string> parsing_table;
set<char> terminals, non_terminals;
char start_symbol;

bool isTerminal(char c) {
    return !isupper(c) && c != '@';
}

void inputGrammar() {
    int n;
    cout << "Enter number of productions: ";
    cin >> n;
    cout << "Enter productions (Format: A->α, use @ for epsilon):\n";

    for (int i = 0; i < n; i++) {
        string prod;
        cin >> prod;
        char lhs = prod[0];
        string rhs = prod.substr(3);
        grammar[lhs].push_back(rhs);
        non_terminals.insert(lhs);
        if (i == 0) start_symbol = lhs;

        for (char c : rhs) {
            if (isTerminal(c) && c != '@')
                terminals.insert(c);
        }
    }
    terminals.insert('$'); // end marker
}

set<char> computeFirst(char symbol);

set<char> computeFirstString(const string& str) {
    set<char> result;
    bool allNullable = true;

    for (char sym : str) {
        set<char> firstSet = computeFirst(sym);
        result.insert(firstSet.begin(), firstSet.end());
        if (firstSet.find('@') == firstSet.end()) {
            allNullable = false;
            break;
        } else {
            result.erase('@');
        }
    }

    if (allNullable)
        result.insert('@');

    return result;
}

set<char> computeFirst(char symbol) {
    if (isTerminal(symbol)) return {symbol};
    if (FIRST.count(symbol)) return FIRST[symbol];

    set<char> result;
    for (string prod : grammar[symbol]) {
        set<char> temp = computeFirstString(prod);
        result.insert(temp.begin(), temp.end());
    }

    return FIRST[symbol] = result;
}

void computeAllFirst() {
    for (char nt : non_terminals)
        computeFirst(nt);
}

void computeFollow() {
    FOLLOW[start_symbol].insert('$');
    bool changed = true;

    while (changed) {
        changed = false;

        for (auto& rule : grammar) {
            char A = rule.first;
            for (string prod : rule.second) {
                for (int i = 0; i < prod.size(); ++i) {
                    char B = prod[i];
                    if (!non_terminals.count(B)) continue;

                    string beta = prod.substr(i + 1);
                    set<char> first_beta = computeFirstString(beta);
                    size_t before = FOLLOW[B].size();

                    for (char f : first_beta)
                        if (f != '@') FOLLOW[B].insert(f);

                    if (first_beta.count('@') || beta.empty()) {
                        FOLLOW[B].insert(FOLLOW[A].begin(), FOLLOW[A].end());
                    }

                    if (FOLLOW[B].size() > before)
                        changed = true;
                }
            }
        }
    }
}

void buildParsingTable() {
    for (auto& rule : grammar) {
        char A = rule.first;
        for (string alpha : rule.second) {
            set<char> first_set = computeFirstString(alpha);

            for (char a : first_set) {
                if (a != '@') parsing_table[{A, a}] = alpha;
            }

            if (first_set.count('@')) {
                for (char b : FOLLOW[A])
                    parsing_table[{A, b}] = alpha;
            }
        }
    }
}

void displayFirstFollow() {
    cout << "\nFIRST sets:\n";
    for (auto& p : FIRST) {
        cout << "FIRST(" << p.first << ") = { ";
        for (char c : p.second) cout << c << " ";
        cout << "}\n";
    }

    cout << "\nFOLLOW sets:\n";
    for (auto& p : FOLLOW) {
        cout << "FOLLOW(" << p.first << ") = { ";
        for (char c : p.second) cout << c << " ";
        cout << "}\n";
    }
}

void displayParsingTable() {
    cout << "\nLL(1) Parsing Table:\n\nNT/T\t";
    for (char t : terminals)
        cout << t << "\t";
    cout << "\n";

    for (char nt : non_terminals) {
        cout << nt << "\t";
        for (char t : terminals) {
            if (parsing_table.count({nt, t}))
                cout << nt << "->" << parsing_table[{nt, t}] << "\t";
            else
                cout << "-\t";
        }
        cout << "\n";
    }
}

bool parseInput(const string& input) {
    string in = input + "$";
    stack<char> st;
    st.push('$');
    st.push(start_symbol);
    int ip = 0;

    cout << "\nParsing Steps:\n";
    cout << "Stack\t\tInput\t\tAction\n";
    while (!st.empty()) {
        string stk;
        stack<char> temp = st;
        vector<char> reversed;
        while (!temp.empty()) {
            reversed.push_back(temp.top());
            temp.pop();
        }
        for (char c : reversed) stk += c;

        string rem_input = in.substr(ip);
        cout << stk << "\t\t" << rem_input << "\t\t";

        char X = st.top();
        char a = in[ip];

        if (X == a) {
            st.pop();
            ip++;
            cout << "Match " << a << "\n";
        } else if (isTerminal(X)) {
            cout << "Error: terminal mismatch\n";
            return false;
        } else if (parsing_table.count({X, a})) {
            string rhs = parsing_table[{X, a}];
            cout << "Apply " << X << "->" << rhs << "\n";
            st.pop();
            if (rhs != "@") {
                for (int j = rhs.size() - 1; j >= 0; j--) {
                    st.push(rhs[j]);
                }
            }
        } else {
            cout << "Error: no rule for (" << X << "," << a << ")\n";
            return false;
        }
    }

    // ✅ FINAL FIX: use length check
    return (ip == in.length() && st.empty());
}

int main() {
    inputGrammar();
    computeAllFirst();
    computeFollow();
    buildParsingTable();

    displayFirstFollow();
    displayParsingTable();

    string input;
    cout << "\nEnter input string to parse: ";
    cin >> input;

    if (parseInput(input))
        cout << "\n✅ Input string is accepted.\n";
    else
        cout << "\n❌ Input string is rejected.\n";

    return 0;
}


#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <set>
#include <algorithm>

using namespace std;

struct Operation {
    char lhs;
    string rhs;
};

int main() {
    int n;
    cout << "Enter the number of instructions: ";
    cin >> n;

    vector<Operation> original(n);
    set<char> usedLater;
    cin.ignore();

    // Input
    for (int i = 0; i < n; ++i) {
        cout << "Left operand [" << i + 1 << "]: ";
        cin >> original[i].lhs;
        cout << "\tRight expression [" << i + 1 << "]: ";
        cin >> original[i].rhs;
    }

    cout << "\n--- Intermediate Code ---\n";
    for (auto& op : original) {
        cout << op.lhs << " = " << op.rhs << endl;
    }

    // Step 1: Dead Code Elimination (keep only used vars)
    set<char> essential;
    essential.insert(original.back().lhs); // Final result must be used

    // Scan backwards to find used vars
    for (int i = n - 1; i >= 0; --i) {
        if (essential.count(original[i].lhs)) {
            for (char c : original[i].rhs) {
                if (isalpha(c)) {
                    essential.insert(c);
                }
            }
        }
    }

    vector<Operation> live;
    for (auto& op : original) {
        if (essential.count(op.lhs)) {
            live.push_back(op);
        }
    }

    cout << "\n--- After Dead Code Elimination ---\n";
    for (auto& op : live) {
        cout << op.lhs << " = " << op.rhs << endl;
    }

    // Step 2: Common Subexpression Elimination (CSE)
    unordered_map<string, char> exprToVar;
    for (int i = 0; i < live.size(); ++i) {
        if (exprToVar.count(live[i].rhs)) {
            char existing = exprToVar[live[i].rhs];
            char toReplace = live[i].lhs;

            // Replace all future uses of toReplace with existing
            for (int j = i + 1; j < live.size(); ++j) {
                for (char& c : live[j].rhs) {
                    if (c == toReplace) c = existing;
                }
            }

            // Overwrite this line as it's redundant
            live[i].lhs = '\0'; // mark for removal
        } else {
            exprToVar[live[i].rhs] = live[i].lhs;
        }
    }

    cout << "\n--- Optimized Code ---\n";
    for (auto& op : live) {
        if (op.lhs != '\0')
            cout << op.lhs << " = " << op.rhs << endl;
    }

    return 0;
}

#include <iostream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <cctype>
using namespace std;
struct Instruction {
string result, arg1, op, arg2;
};
// Returns true if s is a valid constant (all digits)
bool isConstant(const string& s) {
if (s.empty()) return false;
for (char ch : s) {
if (!isdigit(ch)) return false;
}
return true;
}
int eval(int a, string op, int b) {
if (op == "+") return a + b;
if (op == "-") return a - b;
if (op == "*") return a * b;
if (op == "/") return b != 0 ? a / b : 0;
return 0;
}
int main() {
int n;
cout << "Enter number of TAC instructions: ";
cin >> n;
cin.ignore();
vector<Instruction> code;
unordered_map<string, string> constVals;
cout << "Enter TAC instructions (e.g., t1 = 4 + 5):\n";
for (int i = 0; i < n; ++i) {
string line;
getline(cin, line);
stringstream ss(line);
string result, eq, arg1, op, arg2;
ss >> result >> eq >> arg1 >> op >> arg2;
code.push_back({result, arg1, op, arg2});
}
cout << "\n--- Optimized TAC with Constant Folding and Propagation ---\n";
for (auto& inst : code) {
string a1 = inst.arg1, a2 = inst.arg2;// Apply constant propagation if available
if (constVals.count(a1)) a1 = constVals[a1];
if (constVals.count(a2)) a2 = constVals[a2];
if (isConstant(a1) && isConstant(a2)) {
int val1 = stoi(a1);
int val2 = stoi(a2);
int resultVal = eval(val1, inst.op, val2);
cout << inst.result << " = " << resultVal << endl;
constVals[inst.result] = to_string(resultVal);
} else {
cout << inst.result << " = " << a1 << " " << inst.op << " " << a2 << endl;
constVals.erase(inst.result);
}
}
return 0;
}

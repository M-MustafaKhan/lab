#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <tuple>
#include <iomanip>
using namespace std;

struct LR1Item {
    string lhs;
    string rhs;
    int dot;
    char lookahead;

    bool operator<(const LR1Item& other) const {
        return tie(lhs, rhs, dot, lookahead) < tie(other.lhs, other.rhs, other.dot, other.lookahead);
    }

    bool operator==(const LR1Item& other) const {
        return lhs == other.lhs && rhs == other.rhs && dot == other.dot && lookahead == other.lookahead;
    }

    string toString() const {
        string res = lhs + " → ";
        for (int i = 0; i < rhs.size(); ++i) {
            if (i == dot) res += ".";
            res += rhs[i];
        }
        if (dot == rhs.size()) res += ".";
        res += ", ";
        res += lookahead;
        return res;
    }
};

using LR1ItemSet = set<LR1Item>;
map<string, vector<string>> grammar;
set<string> non_terminals;
set<char> terminals;
vector<LR1ItemSet> states;
map<pair<int, char>, int> transitions;
string start_symbol;

bool isTerminal(char c) {
    return !isupper(c) && c != '@';
}

set<char> computeFirst(const string& str) {
    set<char> result;
    if (str.empty()) return {'@'};

    char c = str[0];
    if (isTerminal(c)) {
        result.insert(c);
        return result;
    }

    for (const string& prod : grammar[string(1, c)]) {
        if (prod[0] == '@') result.insert('@');
        else result.insert(prod[0]);
    }

    return result;
}

LR1ItemSet closure(const LR1ItemSet& I) {
    LR1ItemSet closureSet = I;
    queue<LR1Item> q;
    for (auto item : I) q.push(item);

    while (!q.empty()) {
        LR1Item item = q.front(); q.pop();
        if (item.dot >= item.rhs.size()) continue;

        char B = item.rhs[item.dot];
        string Bstr(1, B);
        if (!non_terminals.count(Bstr)) continue;

        string beta = item.rhs.substr(item.dot + 1);
        beta += item.lookahead;
        set<char> firstSet = computeFirst(beta);

        for (const string& prod : grammar[Bstr]) {
            for (char la : firstSet) {
                LR1Item newItem = {Bstr, prod, 0, la};
                if (!closureSet.count(newItem)) {
                    closureSet.insert(newItem);
                    q.push(newItem);
                }
            }
        }
    }

    return closureSet;
}

LR1ItemSet GOTO_fn(const LR1ItemSet& I, char X) {
    LR1ItemSet next;
    for (const auto& item : I) {
        if (item.dot < item.rhs.size() && item.rhs[item.dot] == X) {
            next.insert({item.lhs, item.rhs, item.dot + 1, item.lookahead});
        }
    }
    return closure(next);
}

int getStateId(const LR1ItemSet& set) {
    for (int i = 0; i < states.size(); ++i)
        if (states[i] == set)
            return i;
    return -1;
}

void constructStates() {
    string rhs = grammar[start_symbol][0];
    LR1ItemSet start = closure({{start_symbol, rhs, 0, '$'}});
    states.push_back(start);
    queue<int> q;
    q.push(0);

    while (!q.empty()) {
        int i = q.front(); q.pop();
        set<char> symbols;

        for (auto item : states[i]) {
            if (item.dot < item.rhs.size())
                symbols.insert(item.rhs[item.dot]);
        }

        for (char X : symbols) {
            LR1ItemSet next = GOTO_fn(states[i], X);
            if (next.empty()) continue;
            int id = getStateId(next);
            if (id == -1) {
                states.push_back(next);
                id = states.size() - 1;
                q.push(id);
            }
            transitions[{i, X}] = id;
        }
    }
}

void displayStates() {
    for (int i = 0; i < states.size(); ++i) {
        cout << "\nState I" << i << ":\n";
        for (auto item : states[i]) {
            cout << "  " << item.toString() << "\n";
        }
    }

    cout << "\nTransitions:\n";
    for (auto [key, val] : transitions) {
        cout << "  I" << key.first << " -- " << key.second << " via '" << key.second << "' --> I" << val << "\n";
    }
}

int main() {
    int n;
    cout << "Enter number of productions: ";
    cin >> n;
    cin.ignore();
    cout << "Enter productions (e.g., S->AB):\n";
    for (int i = 0; i < n; ++i) {
        string prod;
        getline(cin, prod);
        string lhs = prod.substr(0, prod.find("->"));
        string rhs = prod.substr(prod.find("->") + 2);
        grammar[lhs].push_back(rhs);
        non_terminals.insert(lhs);
        for (char c : rhs)
            if (isTerminal(c))
                terminals.insert(c);
    }

    // Augment grammar
    string old_start = grammar.begin()->first;
    start_symbol = old_start + "'";
    grammar[start_symbol] = {old_start};
    non_terminals.insert(start_symbol);
    terminals.insert('$');

    constructStates();
    displayStates();

    return 0;
}

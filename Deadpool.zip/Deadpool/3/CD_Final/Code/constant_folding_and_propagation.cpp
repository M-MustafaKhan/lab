#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <unordered_map>
#include <cctype>

using namespace std;

struct TAC {
    string result;
    string arg1;
    string op;
    string arg2;
};

bool isNumber(const string& s) {
    if (s.empty()) return false;
    for (char c : s) {
        if (!isdigit(c)) return false;
    }
    return true;
}

int evaluate(string a1, string op, string a2) {
    int left = stoi(a1);
    int right = stoi(a2);
    if (op == "+") return left + right;
    if (op == "-") return left - right;
    if (op == "*") return left * right;
    if (op == "/") return left / right;
    return 0;
}

void printTAC(const vector<TAC>& code) {
    for (const auto& line : code) {
        if (line.op.empty())
            cout << line.result << " = " << line.arg1 << endl;
        else
            cout << line.result << " = " << line.arg1 << " " << line.op << " " << line.arg2 << endl;
    }
}

int main() {
    int n;
    cout << "Enter number of TAC instructions: ";
    cin >> n;
    cin.ignore();

    vector<TAC> code(n);
    cout << "Enter TAC in format: result = arg1 [op arg2]\n";
    for (int i = 0; i < n; ++i) {
        string line;
        getline(cin, line);
        istringstream iss(line);
        string equal;
        iss >> code[i].result >> equal >> code[i].arg1;
        if (!(iss >> code[i].op)) code[i].op = "";  // assignment only
        else iss >> code[i].arg2;
    }

    cout << "\n--- Original TAC ---\n";
    printTAC(code);

    // Constant Folding and Propagation
    unordered_map<string, string> constMap;

    for (auto& line : code) {
        // Propagate constants
        if (constMap.count(line.arg1)) line.arg1 = constMap[line.arg1];
        if (constMap.count(line.arg2)) line.arg2 = constMap[line.arg2];

        // Fold constants
        if (line.op != "" && isNumber(line.arg1) && isNumber(line.arg2)) {
            int result = evaluate(line.arg1, line.op, line.arg2);
            line.op = "";
            line.arg1 = to_string(result);
            line.arg2 = "";
        }

        // Propagation: track constant assignments
        if (line.op == "" && isNumber(line.arg1)) {
            constMap[line.result] = line.arg1;
        } else {
            constMap.erase(line.result);  // not a constant anymore
        }
    }

    cout << "\n--- Optimized TAC (Constant Folding + Propagation) ---\n";
    printTAC(code);

    return 0;
}

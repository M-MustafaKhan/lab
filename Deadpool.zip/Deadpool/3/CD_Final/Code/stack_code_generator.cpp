#include <iostream>
#include <stack>
#include <string>
#include <cctype>
#include <algorithm>
using namespace std;
// Check if operator has higher precedence
int precedence(char op) {
if (op == '*' || op == '/') return 2;
if (op == '+' || op == '-') return 1;
return 0;
}
// Convert infix to postfix using stack
string infixToPostfix(string expr) {
stack<char> st;
string postfix = "";
for (char ch : expr) {
if (isspace(ch)) continue;
if (isalnum(ch)) {
postfix += ch;
} else if (ch == '(') {
st.push(ch);
} else if (ch == ')') {
while (!st.empty() && st.top() != '(') {
postfix += st.top(); st.pop();
}
if (!st.empty()) st.pop(); // remove '('
} else {
while (!st.empty() && precedence(st.top()) >= precedence(ch)) {
postfix += st.top(); st.pop();
}
st.push(ch);
}
}
while (!st.empty()) {
postfix += st.top(); st.pop();
}
return postfix;
}
// Generate stack code from postfix
void generateStackCode(string postfix, string resultVar) {
stack<string> st;
int tempCount = 1;
for (char ch : postfix) {
if (isalnum(ch)) {cout << "PUSH " << ch << endl;
st.push(string(1, ch));
} else {
string b = st.top(); st.pop();
string a = st.top(); st.pop();
if (ch == '+') cout << "ADD" << endl;
else if (ch == '-') cout << "SUB" << endl;
else if (ch == '*') cout << "MUL" << endl;
else if (ch == '/') cout << "DIV" << endl;
string temp = "t" + to_string(tempCount++);
st.push(temp);
}
}
cout << "POP " << resultVar << endl;
}
int main() {
string input;
cout << "Enter expression (e.g., a = b + c * d): ";
getline(cin, input);
// Parse assignment
size_t eq = input.find('=');
string resultVar = input.substr(0, eq);
string expr = input.substr(eq + 1);
// Remove spaces
resultVar.erase(remove(resultVar.begin(), resultVar.end(), ' '), resultVar.end());
expr.erase(remove(expr.begin(), expr.end(), ' '), expr.end());
string postfix = infixToPostfix(expr);
cout << "\n--- Stack Code ---\n";
generateStackCode(postfix, resultVar);
return 0;
}

#include <iostream>
#include <map>
#include <set>
#include <queue>
#include <vector>
#include <sstream>

using namespace std;

// Define NFA transition structure
struct NFA {
    set<int> states;
    set<char> alphabet;
    map<int, map<char, set<int>>> transitions;
    int start_state;
    set<int> accept_states;
};

// Define DFA transition structure
struct DFA {
    set<set<int>> states;
    map<set<int>, map<char, set<int>>> transitions;
    set<int> start_state;
    set<set<int>> accept_states;
};

// Hardcode the NFA for (a|b)*abb
NFA buildNFA() {
    NFA nfa;
    nfa.alphabet = {'a', 'b'};

    // Define states
    for (int i = 0; i <= 6; i++) nfa.states.insert(i);

    // Start and Accept
    nfa.start_state = 0;
    nfa.accept_states.insert(6);

    // Define transitions
    // (a|b)* → loop from state 0 to 0 on a or b
    nfa.transitions[0]['a'].insert(0);
    nfa.transitions[0]['b'].insert(0);

    // Followed by 'a' → state 1
    nfa.transitions[0]['a'].insert(1);

    // 'b' → state 2
    nfa.transitions[1]['b'].insert(2);

    // 'b' → state 3
    nfa.transitions[2]['b'].insert(3);

    // Accept state
    nfa.transitions[3]['a'];  // dead transitions (optional)
    nfa.transitions[3]['b'];
    nfa.accept_states = {3};

    return nfa;
}

void convertNFAtoDFA(NFA &nfa, DFA &dfa) {
    queue<set<int>> unprocessed;
    set<int> start_set = {nfa.start_state};
    dfa.start_state = start_set;
    dfa.states.insert(start_set);
    unprocessed.push(start_set);

    while (!unprocessed.empty()) {
        set<int> current = unprocessed.front();
        unprocessed.pop();

        for (char symbol : nfa.alphabet) {
            set<int> next_set;
            for (int state : current) {
                if (nfa.transitions[state].count(symbol)) {
                    next_set.insert(nfa.transitions[state][symbol].begin(),
                                    nfa.transitions[state][symbol].end());
                }
            }
            if (!next_set.empty()) {
                dfa.transitions[current][symbol] = next_set;
                if (dfa.states.find(next_set) == dfa.states.end()) {
                    dfa.states.insert(next_set);
                    unprocessed.push(next_set);
                }
            }
        }
    }

    for (const auto &state_set : dfa.states) {
        for (int s : state_set) {
            if (nfa.accept_states.count(s)) {
                dfa.accept_states.insert(state_set);
                break;
            }
        }
    }
}

string setToString(const set<int> &s) {
    stringstream ss;
    ss << "{";
    for (auto it = s.begin(); it != s.end(); ++it) {
        ss << *it;
        if (next(it) != s.end()) ss << ",";
    }
    ss << "}";
    return ss.str();
}

void printDFA(DFA &dfa, const set<char> &alphabet) {
    cout << "\nDFA States:\n";
    for (const auto &state : dfa.states)
        cout << setToString(state) << "\n";

    cout << "\nStart State: " << setToString(dfa.start_state) << "\n";

    cout << "\nAccept States:\n";
    for (const auto &state : dfa.accept_states)
        cout << setToString(state) << "\n";

    cout << "\nDFA Transition Table:\n";
    for (const auto &state : dfa.states) {
        for (char symbol : alphabet) {
            if (dfa.transitions[state].count(symbol)) {
                cout << setToString(state) << " --" << symbol << "--> "
                     << setToString(dfa.transitions[state][symbol]) << "\n";
            }
        }
    }
}

int main() {
    NFA nfa = buildNFA();
    DFA dfa;

    convertNFAtoDFA(nfa, dfa);
    printDFA(dfa, nfa.alphabet);

    return 0;
}

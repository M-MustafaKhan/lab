#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <iomanip>
#include <stack>
#include <algorithm>
using namespace std;

struct Item {
    string lhs;
    string rhs;
    int dot;

    Item(string l, string r, int d) : lhs(l), rhs(r), dot(d) {}

    bool operator<(const Item& other) const {
        return tie(lhs, rhs, dot) < tie(other.lhs, other.rhs, other.dot);
    }

    bool operator==(const Item& other) const {
        return lhs == other.lhs && rhs == other.rhs && dot == other.dot;
    }

    string toString() const {
        string result = lhs + " → ";
        for (int i = 0; i < rhs.size(); ++i) {
            if (i == dot) result += '.';
            result += rhs[i];
        }
        if (dot == rhs.size()) result += '.';
        return result;
    }
};

using ItemSet = set<Item>;

map<string, vector<string>> grammar;
map<string, set<char>> FIRST, FOLLOW;
vector<ItemSet> states;
map<pair<int, char>, int> GOTO;
map<pair<int, char>, string> ACTION;
set<char> terminals;
set<string> non_terminals;
string start_symbol;

bool isTerminal(char c) {
    return !isupper(c) && c != '@' && c != '\'';
}

void inputGrammar() {
    int n;
    cout << "Enter number of productions (including augmented S'->S): ";
    cin >> n;
    cout << "Enter productions (e.g., S->Aa):\n";
    cin.ignore();
    for (int i = 0; i < n; ++i) {
        string prod;
        getline(cin, prod);
        size_t arrow = prod.find("->");
        string lhs = prod.substr(0, arrow);
        string rhs = prod.substr(arrow + 2);
        grammar[lhs].push_back(rhs);
        non_terminals.insert(lhs);
        if (i == 0) start_symbol = lhs;
        for (char c : rhs) {
            if (isTerminal(c)) terminals.insert(c);
        }
    }
    terminals.insert('$');
}

set<char> computeFIRST(char);

set<char> computeFIRSTString(const string& str) {
    set<char> result;
    bool allNullable = true;
    for (char c : str) {
        set<char> first = computeFIRST(c);
        result.insert(first.begin(), first.end());
        if (first.find('@') == first.end()) {
            allNullable = false;
            break;
        } else {
            result.erase('@');
        }
    }
    if (allNullable) result.insert('@');
    return result;
}

set<char> computeFIRST(char c) {
    for (auto& nt : non_terminals) {
        if (nt.size() == 1 && nt[0] == c)
            return FIRST[nt];
    }
    return {c};
}

void computeAllFIRST() {
    bool changed = true;
    while (changed) {
        changed = false;
        for (auto& [lhs, productions] : grammar) {
            for (auto& rhs : productions) {
                set<char> temp = computeFIRSTString(rhs);
                int before = FIRST[lhs].size();
                FIRST[lhs].insert(temp.begin(), temp.end());
                if (FIRST[lhs].size() != before) changed = true;
            }
        }
    }
}

void computeFOLLOW() {
    FOLLOW[start_symbol].insert('$');
    bool changed = true;
    while (changed) {
        changed = false;
        for (auto& [lhs, productions] : grammar) {
            for (auto& rhs : productions) {
                for (int i = 0; i < rhs.size(); ++i) {
                    char B = rhs[i];
                    string Bstr(1, B);
                    if (!non_terminals.count(Bstr)) continue;
                    string beta = rhs.substr(i + 1);
                    set<char> firstBeta = computeFIRSTString(beta);
                    int before = FOLLOW[Bstr].size();
                    for (char f : firstBeta)
                        if (f != '@') FOLLOW[Bstr].insert(f);
                    if (firstBeta.count('@') || beta.empty()) {
                        FOLLOW[Bstr].insert(FOLLOW[lhs].begin(), FOLLOW[lhs].end());
                    }
                    if (FOLLOW[Bstr].size() != before)
                        changed = true;
                }
            }
        }
    }
}

ItemSet closure(const ItemSet& I) {
    ItemSet result = I;
    queue<Item> q;
    for (const auto& item : I) q.push(item);

    while (!q.empty()) {
        Item it = q.front(); q.pop();
        if (it.dot >= it.rhs.size()) continue;
        char B = it.rhs[it.dot];
        string Bstr(1, B);
        if (!non_terminals.count(Bstr)) continue;

        for (string prod : grammar[Bstr]) {
            Item newItem(Bstr, prod, 0);
            if (!result.count(newItem)) {
                result.insert(newItem);
                q.push(newItem);
            }
        }
    }

    return result;
}

ItemSet GOTO_fn(const ItemSet& I, char X) {
    ItemSet next;
    for (const auto& item : I) {
        if (item.dot < item.rhs.size() && item.rhs[item.dot] == X) {
            next.insert(Item(item.lhs, item.rhs, item.dot + 1));
        }
    }
    return closure(next);
}

int getStateId(const ItemSet& I) {
    for (int i = 0; i < states.size(); ++i)
        if (states[i] == I)
            return i;
    return -1;
}

void constructStates() {
    string rhs = grammar[start_symbol][0];
    ItemSet start = closure({ Item(start_symbol, rhs, 0) });
    states.push_back(start);
    queue<int> q;
    q.push(0);

    while (!q.empty()) {
        int i = q.front(); q.pop();
        set<char> symbols;
        for (const auto& item : states[i])
            if (item.dot < item.rhs.size())
                symbols.insert(item.rhs[item.dot]);

        for (char X : symbols) {
            ItemSet next = GOTO_fn(states[i], X);
            int id = getStateId(next);
            if (id == -1) {
                states.push_back(next);
                id = states.size() - 1;
                q.push(id);
            }
            GOTO[{i, X}] = id;
        }
    }
}

void buildSLRTable() {
    for (int i = 0; i < states.size(); ++i) {
        for (const auto& item : states[i]) {
            if (item.dot < item.rhs.size()) {
                char a = item.rhs[item.dot];
                if (isTerminal(a)) {
                    int j = GOTO[{i, a}];
                    ACTION[{i, a}] = "s" + to_string(j);
                }
            } else {
                if (item.lhs == start_symbol)
                    ACTION[{i, '$'}] = "acc";
                else {
                    for (char b : FOLLOW[item.lhs])
                        ACTION[{i, b}] = "r" + item.lhs + "→" + item.rhs;
                }
            }
        }
    }
}

void displayCanonicalCollection() {
    cout << "\nCanonical Collection of LR(0) Items:\n";
    for (int i = 0; i < states.size(); ++i) {
        cout << "\nI" << i << ":\n";
        for (const auto& item : states[i])
            cout << "  " << item.toString() << "\n";
    }
}

void displayParsingTable() {
    cout << "\nSLR Parsing Table:\n";
    cout << setw(8) << "State";
    for (char t : terminals) cout << setw(8) << t;
    for (string nt : non_terminals)
        if (nt != start_symbol)
            cout << setw(8) << nt;
    cout << "\n";

    for (int i = 0; i < states.size(); ++i) {
        cout << setw(8) << i;
        for (char t : terminals) {
            if (ACTION.count({i, t}))
                cout << setw(8) << ACTION[{i, t}];
            else
                cout << setw(8) << "-";
        }
        for (string nt : non_terminals)
            if (nt != start_symbol) {
                char c = nt[0];
                if (GOTO.count({i, c}))
                    cout << setw(8) << GOTO[{i, c}];
                else
                    cout << setw(8) << "-";
            }
        cout << "\n";
    }
}

void parseInputString(const string& input) {
    cout << "\nParsing Input String: " << input << "\n";
    stack<int> st;
    st.push(0);
    int ip = 0;

    cout << setw(20) << "Stack" << setw(20) << "Input" << setw(20) << "Action\n";

    while (true) {
        int state = st.top();
        char symbol = input[ip];
        string action = ACTION[{state, symbol}];

stack<int> tmp = st;
vector<int> svec;
while (!tmp.empty()) {
    svec.push_back(tmp.top());
    tmp.pop();
}
reverse(svec.begin(), svec.end());

// Print symbol-state stack clearly:
for (size_t i = 0; i < svec.size(); ++i) {
    if (i % 2 == 0) // even index: state
        cout << svec[i];
    else            // odd index: grammar symbol
        cout << (char)svec[i];
}
cout << setw(20);

        cout << input.substr(ip) << setw(20);

        if (action == "acc") {
            cout << "Accept\n";
            break;
        } else if (action[0] == 's') {
            int nextState = stoi(action.substr(1));
            st.push(symbol);
            st.push(nextState);
            cout << "Shift " << symbol << "\n";
            ip++;
        } else if (action[0] == 'r') {
            string lhs = action.substr(1, action.find("→") - 1);
            string rhs = action.substr(action.find("→") + 3);
            int popLen = rhs == "@" ? 0 : rhs.length() * 2;
            while (popLen--) st.pop();
            int top = st.top();
            st.push(lhs[0]); // push first char of LHS
            st.push(GOTO[{top, lhs[0]}]);
            cout << "Reduce " << lhs << " → " << rhs << "\n";
        } else {
            cout << "ERROR: No action found\n";
            break;
        }
    }
}

int main() {
    inputGrammar();
    computeAllFIRST();
    computeFOLLOW();
    constructStates();
    buildSLRTable();
    displayCanonicalCollection();
    displayParsingTable();

    string str;
    cout << "\nEnter string to parse (without $): ";
    cin >> str;
    parseInputString(str + "$");

    return 0;
}

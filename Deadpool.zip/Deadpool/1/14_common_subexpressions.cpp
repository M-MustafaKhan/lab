#include <iostream>
#include <vector>
#include <unordered_map>
#include <sstream>
using namespace std;
struct Instruction {
string result, arg1, op, arg2;
};
int main() {
int n;
cout << "Enter number of TAC instructions: ";
cin >> n;
cin.ignore();
vector<Instruction> code;
unordered_map<string, string> exprToTemp;
cout << "Enter TAC instructions (e.g., t1 = a + b):\n";
for (int i = 0; i < n; ++i) {
string line;
getline(cin, line);
stringstream ss(line);
string res, eq, a1, op, a2;
ss >> res >> eq >> a1 >> op >> a2;
code.push_back({res, a1, op, a2});
}
cout << "\n--- Optimized TAC After Common Subexpression Elimination ---\n";
for (const auto& inst : code) {
string key = inst.arg1 + inst.op + inst.arg2;
if (exprToTemp.find(key) != exprToTemp.end()) {
// Subexpression already computed
cout << inst.result << " = " << exprToTemp[key] << " // eliminated: "
<< inst.arg1 << " " << inst.op << " " << inst.arg2 << endl;
} else {
// Not found — store and emit normally
exprToTemp[key] = inst.result;
cout << inst.result << " = " << inst.arg1 << " " << inst.op << " " << inst.arg2 << endl;
}
}
return 0;
}

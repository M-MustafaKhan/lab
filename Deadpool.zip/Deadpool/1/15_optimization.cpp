// Implement constant folding and constant propagation optimization techniques by considering Three Address Code Instructions

#include <iostream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <cctype>
using namespace std;

struct Instruction {
    string lhs, op1, op, op2;
};

bool isNumber(const string &s) {
    if (s.empty()) return false;
    for (char c : s) if (!isdigit(c) && c != '-') return false;
    return true;
}

string evaluate(string a, string op, string b) {
    int val1 = stoi(a);
    int val2 = stoi(b);
    int result;

    if (op == "+") result = val1 + val2;
    else if (op == "-") result = val1 - val2;
    else if (op == "*") result = val1 * val2;
    else if (op == "/") result = val2 != 0 ? val1 / val2 : 0;
    else result = 0;

    return to_string(result);
}

int main() {
    int n;
    cout << "Enter number of instructions: ";
    cin >> n;
    cin.ignore();

    vector<Instruction> code;
    unordered_map<string, string> constMap;

    cout << "Enter TAC instructions (e.g., t1 = 2 + 3):\n";
    for (int i = 0; i < n; ++i) {
        string line;
        getline(cin, line);
        stringstream ss(line);
        string lhs, eq, op1, op, op2;
        ss >> lhs >> eq >> op1;
        if (ss >> op >> op2) {
            code.push_back({lhs, op1, op, op2});
        } else {
            code.push_back({lhs, op1, "", ""});
        }
    }

    cout << "\nOptimized Code:\n";
    for (auto &inst : code) {
        string op1 = inst.op1, op2 = inst.op2;
        bool propagated = false;

        if (constMap.count(op1)) {
            op1 = constMap[op1];
            propagated = true;
        }
        if (constMap.count(op2)) {
            op2 = constMap[op2];
            propagated = true;
        }

        if (!inst.op.empty() && isNumber(op1) && isNumber(op2)) {
            string result = evaluate(op1, inst.op, op2);
            cout << inst.lhs << " = " << result << "   (Constant Folding Applied";
            if (propagated) cout << ", Constant Propagation Applied";
            cout << ")\n";
            constMap[inst.lhs] = result;
        }
        else if (inst.op.empty() && isNumber(op1)) {
            cout << inst.lhs << " = " << op1 << "   (Constant Propagation Applied)\n";
            constMap[inst.lhs] = op1;
        }
        else {
            cout << inst.lhs << " = " << op1;
            if (!inst.op.empty()) cout << " " << inst.op << " " << op2;
            if (propagated) cout << "   (Constant Propagation Applied)";
            cout << endl;
            constMap.erase(inst.lhs);
        }
    }

    return 0;
}

/* Enter number of instructions: 5
t1 = 2 + 3
t2 = t1 * 4
t3 = t2 - 6
t4 = t3
t5 = t4 + t1 */
